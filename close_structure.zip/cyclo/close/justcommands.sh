gmx_mpi_d grompp -f mtd -c after_em -p molecule_gmx.top -o mtd1
mpirun -np 1 gmx_mpi_d mdrun -deffnm mtd1 -plumed plumed_v2.dat

