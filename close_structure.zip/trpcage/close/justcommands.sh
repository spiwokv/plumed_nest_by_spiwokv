gmx_mpi_d grompp -maxwarn 1 -f md1 -c after_em1 -p trpcage -o mtd1
mpirun -np 1 gmx_mpi_d mdrun -s mtd1 -o mtd1 -e mtd1 -g mtd1 -c after_mtd1 -plumed plumed

