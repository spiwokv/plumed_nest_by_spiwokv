for i in `seq 0 39`;
do
gmx_mpi_d grompp -f mtd -c frame$i -p AceProProNH2 -o mtd1_$i -maxwarn 666
rm mdout.mdp
done
mpirun -np 40 --hostfile hostfile gmx_mpi_d mdrun -s mtd1_ -o mtd1_ -e mtd1_ -g mtd1_ -c after_mtd1_ -plumed plumed -multi 40


