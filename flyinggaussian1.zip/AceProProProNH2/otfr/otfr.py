#!/usr/bin/python

import math

data = []
ifile = open("../COLVAR.0", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.1", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.2", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.3", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.4", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.5", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.6", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.7", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.8", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.9", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.10", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.11", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.12", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.13", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.14", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.15", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.16", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.17", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.18", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.19", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.20", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.21", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.22", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.23", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.24", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.25", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.26", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.27", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.28", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.29", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.30", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.31", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.32", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.33", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.34", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.35", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.36", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.37", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.38", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.39", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.40", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.41", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.42", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.43", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.44", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.45", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.46", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.47", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.48", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.49", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.50", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.51", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.52", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.53", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.54", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.55", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.56", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.57", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.58", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.59", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.60", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.61", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.62", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.63", "r").readlines()
for i in range(1000,len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])

pops = []
x = 0.0
while x < 3.001:
  x = x + 0.02
  pops.append(0.0)

maxpop = 0.0
for line in data:
  xi = int(line[0]/0.02)
  pops[xi] = pops[xi] + math.exp(line[1]/8.314/0.3)
  if pops[xi] > maxpop:
    maxpop = pops[xi]

x = 0.0
i = 0
while x < 3.001:
  print x, -8.314*0.3*math.log(pops[i]/maxpop)
  x = x + 0.02
  i = i + 1

