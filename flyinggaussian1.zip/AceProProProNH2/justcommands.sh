for i in `seq 0 63`;
do
gmx_mpi_d grompp -f mtd -c frame$i -p AceProProProNH2 -o mtd1_$i -maxwarn 666
rm mdout.mdp
done
mpirun -np 64 gmx_mpi_d mdrun -s mtd1_ -o mtd1_ -e mtd1_ -g mtd1_ -c after_mtd1_ -plumed plumed -multi 64

