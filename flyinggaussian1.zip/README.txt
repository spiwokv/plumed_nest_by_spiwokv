Input files (input structures, topology, Plumed input files) for simulations used
to demonstrate functionality of Flying Gaussian algorithm (J. Chem. Theory Comput.
2016, 12, 4644-4650). The method simulates a molecular system in multiple replicas
and enhances sampling by disfavoring states that are close to each other in different
replicas. Input files for Flying Gaussian simulation of alanine dipeptide in vacuum
and water, cis/trans isomerization of Ace-(Pro)n-NH2 and Met-enkephalin are provided.
In most cases, longer simulation have to be done to reproduce results from the
article. Scripts for calculation of free energy surfaces by reweighing are provided.
Input data for cis/trans isomerization of Ace-(Pro)n-NH2 were modified relative to
the publication in the way that implicit solvent was replaced by explicit one due
to lack of support for implicit solvents in recent Gromacs versions. Tested on
OpenMPI4.0.0, Gromacs 2018.5 and Plumed2.5.0. Submission scripts are provided.

Directories:
acealanmevacuum - demonstration of Flying Gaussian method on alanine dipeptide in
vacuum with Ramachandran torsions as CVs

acealanmewater8 - demonstration of Flying Gaussian method on alanine dipeptide in
water with Ramachandran torsions as CVs and 8 walkers

acealanmewater16 - demonstration of Flying Gaussian method on alanine dipeptide in
water with Ramachandran torsions as CVs and 16 walkers

acealanmewater32 - demonstration of Flying Gaussian method on alanine dipeptide in
water with Ramachandran torsions as CVs and 32 walkers

acealanmewater64 - demonstration of Flying Gaussian method on alanine dipeptide in
water with Ramachandran torsions as CVs and 64 walkers

AceProNH2 - demonstration of Flying Gaussian method on AceProNH2 in water with
cis/trans isomerization CV and 20 walkers

AceProProNH2 - demonstration of Flying Gaussian method on AceProProNH2 in water
with cis/trans isomerization CV and 40 walkers

AceProProProNH2 - demonstration of Flying Gaussian method on AceProProProNH2 in
water with cis/trans isomerization CV and 64 walkers

metenkephalin - demonstration of Flying Gaussian method on Met-enkephalin in water
with CVs taken from J. Chem. Theory Comput. 2010, 612, 3640-3646 and 20 walkers

Files:
*.gro - input structures after minimization or equilibration

*.mdp - Gromacs simulation command files

*.top – Gromacs topology files

hostfile - file used by MPI

justcommands.sh - commands to be run

otfr.py - reweighing Python scripts

plumed.dat - plumed input files

runit.sh - actual scripts used in the simulations

