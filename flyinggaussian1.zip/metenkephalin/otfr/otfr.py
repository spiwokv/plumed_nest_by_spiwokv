#!/usr/bin/python

import math

nwalkers = 20

data = []
for i in range(nwalkers):
  ifilename = "../colvar."+str(i)
  ifile = open(ifilename, "r").readlines()
  walker = []
  for line in ifile:
    if line[0]!="#":
      sline = str.split(line)
      #if ((float(sline[0]) > 100.0)): # and (float(sline[0]) < 9000.1)):
      walker.append([float(sline[1]), float(sline[2]), float(sline[3]), float(sline[4])])
  data.append(walker)

def onestep(step):
  pop = []
  sumpop = 0.0
  for i in range(90):
    popline = []
    for j in range(110):
      #popline2 = []
      #for k in range(70):
      popline.append(0.0)
      #popline.append(popline2)
    pop.append(popline)
  maxpop = 0
  for walker in data:
    for i in range(100,1000*step):
      x = int(90.0*walker[i][0]/1.8)
      y = int(110.0*walker[i][1]/2.2)
      #z = int(70.0*walker[i][2]/1.4)
      pot = walker[i][3]
      addpop = math.exp(pot/8.314/0.3)
      pop[x][y] = pop[x][y] + addpop
      if pop[x][y] > maxpop:
        maxpop = pop[x][y]
  fes = []
  #fesmin = 1000000000.0
  for i in range(90):
    fesline = []
    for j in range(110):
      if pop[i][j] > 0.0:
        fe = -8.314*0.3*math.log(pop[i][j]/maxpop)
      else:
        fe = 100.0
      #if fe < fesmin:
      #fesmin = fe
      fesline.append(fe)
    fes.append(fesline)
  ofilename = "fes"+str(step)+".txt"
  ofile = open(ofilename, "w")
  for i in range(90):
    for j in range(110):
      ofile.write(" %i %i %f\n" % (i, j, fes[i][j]))
  ofile.close()

for i in range(252):
  onestep(i)

