for i in `seq 0 19`;
do
gmx_mpi_d grompp -f fg_1ns -c frame$i -p topol -o mtd1_$i -maxwarn 666
rm mdout.mdp
done
mpirun -np 20 -bind-to core gmx_mpi_d mdrun -s mtd1_ -o mtd1_ -e mtd1_ -g mtd1_ -c after_mtd1_ -plumed plumed -multi 20



