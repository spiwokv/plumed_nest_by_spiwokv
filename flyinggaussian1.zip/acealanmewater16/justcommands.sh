export OMP_NUM_THREADS=1
for i in `seq 0 15`;
do
gmx_mpi grompp -f mtd.mdp -c frame$i.gro -p AceAlaNme.top -o mtd1_$i -maxwarn 666
rm mdout.mdp
done
mpirun -np 16 gmx_mpi mdrun -s mtd1_ -o mtd1_ -e mtd1_ -g mtd1_ -c after_mtd1_ -plumed plumed -multi 16

