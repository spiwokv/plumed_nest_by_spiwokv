#!/usr/bin/python

import math

nwalkers = 16

data = []
for i in range(nwalkers):
  ifilename = "../COLVAR."+str(i)
  ifile = open(ifilename, "r").readlines()
  walker = []
  for line in ifile:
    if line[0]!="#":
      sline = str.split(line)
      #if ((float(sline[0]) > 100.0)): # and (float(sline[0]) < 9000.1)):
      walker.append([float(sline[1]), float(sline[2]), float(sline[3])])
  data.append(walker)

def onestep(step):
  pop = []
  sumpop = 0.0
  for i in range(48):
    popline = []
    for j in range(48):
      popline.append(0.0)
    pop.append(popline)
  for walker in data:
    for i in range(100,100*step):
      x = int(24.0*(walker[i][0]+math.pi)/math.pi)
      y = int(24.0*(walker[i][1]+math.pi)/math.pi)
      pot = walker[i][2]
      addpop = math.exp(pot/8.314/0.3)
      pop[x][y] = pop[x][y] + addpop
      sumpop = sumpop + addpop
  fes = []
  fesmin = 1000000000.0
  for i in range(48):
    fesline = []
    for j in range(48):
      if pop[i][j] > 0.0:
        fe = -8.314*0.3*math.log(pop[i][j]/sumpop)
      else:
        fe = 100.0
      if fe < fesmin:
        fesmin = fe
      fesline.append(fe)
    fes.append(fesline)
  ofilename = "fes"+str(step)+".txt"
  ofile = open(ofilename, "w")
  for i in range(48):
    for j in range(48):
      ofile.write(" %i %i %f\n" % (i, j, fes[i][j]-fesmin))
  ofile.close()

#for i in range(501):
onestep(500)

