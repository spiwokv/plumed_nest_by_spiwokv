#!/usr/bin/python

import math

data = []

ifile = open("../COLVAR.0", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.1", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.2", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.3", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.4", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.5", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.6", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.7", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.8", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.9", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.10", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.11", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.12", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.13", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.14", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.15", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.16", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.17", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.18", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])
ifile = open("../COLVAR.19", "r").readlines()
for i in range(len(ifile)):
  if ifile[i][0]!="#":
    sline = str.split(ifile[i])
    data.append([float(sline[1]),float(sline[2])])

pops = []
x = 0.0
while x < 1.001:
  x = x + 0.02
  pops.append(0.0)

maxpop = 0.0
for line in data:
  xi = int(line[0]/0.02)
  pops[xi] = pops[xi] + math.exp(line[1]/8.314/0.3)
  if pops[xi] > maxpop:
    maxpop = pops[xi]

x = 0.0
i = 0
while x < 1.001:
  print x, -8.314*0.3*math.log(pops[i]/maxpop)
  x = x + 0.02
  i = i + 1

