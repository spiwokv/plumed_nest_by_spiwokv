export OMP_NUM_THREADS=1
for i in `seq 0 63`;
do
/software/plumed/gromacs20185plumed250/bin/gmx_mpi grompp -f mtd.mdp -c frame$i.gro -p AceAlaNme.top -o mtd1_$i -maxwarn 666
rm mdout.mdp
done
/software/mpi/openmpi400/bin/mpirun -x OMP_NUM_THREADS=1 -np 64 --hostfile hostfile /software/plumed/gromacs20185plumed250/bin/gmx_mpi mdrun -s mtd1_ -o mtd1_ -e mtd1_ -g mtd1_ -c after_mtd1_ -plumed plumed -multi 64

